<?php

namespace App\Http\Controllers;

use App\Models\semesterStudent;
use Illuminate\Http\Request;

class SemesterStudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\semesterStudent  $semesterStudent
     * @return \Illuminate\Http\Response
     */
    public function show(semesterStudent $semesterStudent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\semesterStudent  $semesterStudent
     * @return \Illuminate\Http\Response
     */
    public function edit(semesterStudent $semesterStudent)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\semesterStudent  $semesterStudent
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, semesterStudent $semesterStudent)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\semesterStudent  $semesterStudent
     * @return \Illuminate\Http\Response
     */
    public function destroy(semesterStudent $semesterStudent)
    {
        //
    }
}
